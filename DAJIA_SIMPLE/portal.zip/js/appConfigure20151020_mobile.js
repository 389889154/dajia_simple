/*移动端方法定义==========================*/
//轮播图片容器高度,logo容器的宽高
function scrollPreviewHeight(obj) {
    var swiperWrapperWidth = obj.width();
    obj.height(parseInt(swiperWrapperWidth * 0.4)) //0.4是轮播图实际区域的宽高比
    //轮播图片为logo的
		var logoLayer=obj.find(".mApp_setting_logoLayer"); //logo的背景容器
		var logoWrapper=obj.find(".mApp_setting_logoWrapper"); //logo容器
		var logoWrapperWidth=parseInt(swiperWrapperWidth/(320/80)); //320/80是logo最外层轮播区域与logo容器的宽度比
		logoLayer.css({"width":swiperWrapperWidth,"height":parseInt(swiperWrapperWidth * 0.4)});
		logoWrapper.css({"width":logoWrapperWidth,"height":logoWrapperWidth}); //logo容器为圆形
}

//页面大背景宽度和背景图片左侧值
function backgroundImgWidth(){
	var bgWidth=$(".mCommon_frameContent0_page").innerWidth();
	var contentOffset=$(".mCommon_frameContent0_page").offset();
	$(".mApp_setting_bg").width(bgWidth).css("left",Math.round(contentOffset.left)+"px");
}

//字符缩小20150929
function stringMinify(obj){//obj为jq对象,当金额容器的宽度超过容器最大字符数，字号变小
		function fontSize(obj){
			objStrLength=obj.children("span").text().length; //字符长度
	 		if(objStrLength >= 18){
	 			obj.removeClass("mCommon_basicShopItemPortal_sizeBig").addClass("mCommon_basicShopItemPortal_sizeSmall")
			}else{
				obj.removeClass("mCommon_basicShopItemPortal_sizeSmall").addClass("mCommon_basicShopItemPortal_sizeBig")
			}
		}
		fontSize(obj);
}
/*移动端方法定义end==========================*/


/*原有移动页面执行===========================*/

$().ready(function(){
	//页面大背景宽度和背景图片左侧值
	backgroundImgWidth();
	
	$(window).resize(function() {
		backgroundImgWidth();
		scrollPreviewHeight($('.mApp_setting_swiperWrapper'));
	});
	
	//金额大于20个字符，字号缩小
	$(".mCommon_basicShopItemPortal_money").each(function() {
			stringMinify($(this));
	});
		//金额大于20个字符，字号缩小end
	
	/*解决qq浏览器和微信在米2s上的字体图标不显示的问题*/
	var version = "?v=1234"; //添加版本号
	var ua = navigator.userAgent;
	var styleHtml = '<style>@font-face {font-family: "iconfont";src: url("../../sprint3/images/iconfont_app/iconfont.svg' + version + '") format("svg")}</style>';
	if (ua.indexOf("MI 2S") > 0 && ua.indexOf("MQQBrowser") > 0) {
		$("head").append(styleHtml);
	}
	/*解决qq浏览器和微信在米2s上的字体图标不显示的问题 end*/

/*移动端调用end========*/

});

