  	var da= {};
	da.djJsNeedInterface = true;
	da.djJsReady = false;
	da.djJsDebug = false;
	da.readyFun;
	da.errorFun;
	da.functionMap= {};
	da.version;
	da.djInjs = false;
	da.check = function(data){
		this.djInjs = true;
		if(data=="ok"){
			this.djJsReady = true;
			if(this.readyFun)
				this.readyFun();
			return;
		}
		if(data=="error"){
			this.djJsReady = false;
			if(this.errorFun)
				this.errorFun();
			return;
		}
		if (typeof (data) != "object") {
			data = eval('(' + data + ')');
		}
		if(data.msg=="ok"){
			this.djJsReady = true;
			this.functionMap = data.fun||{};
			if(this.readyFun)
				this.readyFun();
		}else{
			this.djJsReady = false;
			if(this.errorFun)
				this.errorFun();
		}
	};
	
	da.canTrans = function(){
		return this.djJsReady && typeof(djInternal)!='undefined';
	};


	//对前台页面提供的接口
  	da.config = function(v){
		this.djJsDebug=v.debug;
		this.djJsNeedInterface = true;
	};
	da.ready = function(v){
		this.readyFun = v;
		if(this.djInjs && da.djJsReady){
			this.readyFun();
		}
	};
	da.error = function(v){
		this.errorFun = v;
		if(this.djInjs && da.djJsReady == false){
			this.errorFun();
		}
	};
	da.checkFun = function(v){
		if(this.functionMap && eval('this.functionMap.'+v.funName)){
			v.success();
		}else if(this.canTrans()){
			djInternal.callHandler('checkFun', {'funName':v.funName},
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success();
				break;
				case 'fail':
				  v.fail();
				break;
				default:
				  v.fail();
				break;
			  }
			});
		}else{
			v.fail();
		}
	};
  	da.showReadList=function(v){
		if(this.canTrans())
			djInternal.callHandler('showReadList', {'feedID':v.feedID,'communityID':v.communityID});
  	};
  	da.showPraiseList=function(v){
		if(this.canTrans())
			djInternal.callHandler('showPraiseList', {'feedID':v.feedID,'communityID':v.communityID});
  	};
  	da.showCommentList=function(v){
		if(this.canTrans())
			djInternal.callHandler('showCommentList', {'feedID':v.feedID,'communityID':v.communityID});
  	};
	da.showPerson = function(v){
		if(this.canTrans())
			djInternal.callHandler('showPerson', {'personID':v.personID,'personName':v.personName});
	};
	da.showGroup = function(v){
		if(this.canTrans())
			djInternal.callHandler('showGroup', {'groupID':v.groupID,'groupName':v.groupName});
	};
  	da.joinCommunity=function(v){
		if(this.canTrans())
			djInternal.callHandler('joinCommunity', {'communityID':v.communityID});
  	};
  	da.enterCommunity=function(v){
		if(this.canTrans())
			djInternal.callHandler('enterCommunity', {'communityID':v.communityID,'communityName':v.communityName});
  	};
  	da.enterExperience=function(v){
		if(this.canTrans())
			djInternal.callHandler('enterExperience', {'communityID':v.communityID,'username':v.username,'password':v.password});
  	};
  	da.joinGroup=function(v){
		if(this.canTrans())
			djInternal.callHandler('joinGroup', {'communityID':v.communityID,'groupID':v.groupID});
  	};
	da.showPicList = function(v){
		if(this.canTrans())
			djInternal.callHandler('showPicList', {'current':v.current,'ids':v.ids});
	};
	da.showFile = function(v){
		if(this.canTrans())
			djInternal.callHandler('showFile', {'fileID':v.fileID,'fileName':v.fileName,'fileSize':v.fileSize});
	};
	da.showLocation = function(v){
		if(this.canTrans())
			djInternal.callHandler('showLocation', {'lat':v.lat,'lon':v.lon,'name':v.name,'addr':v.addr});
	};
	da.getLocation = function(v){
		if(this.canTrans())
			djInternal.callHandler('getLocation', {'current':v.current}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};
	da.showScan = function(v){
		if(this.canTrans())
			djInternal.callHandler('showScan', {'needResult':v.needResult}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};
	da.showQRCode = function(v){
		if(this.canTrans())
			djInternal.callHandler('showQRCode', {'url':v.url}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};
	da.getNetWorkType = function(v){
		if(this.canTrans())
			djInternal.callHandler('getNetWorkType', {}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};
	da.chooseImage = function(v){
		if(this.canTrans())
			djInternal.callHandler('chooseImage', {type: v.type,current: v.current, max: v.max},
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};
	da.previewImage = function(v){
		if(this.canTrans())
			djInternal.callHandler('previewImage', {'current':v.current,'urls':v.urls});
	};
	da.uploadImage = function(v){
		if(this.canTrans())
			djInternal.callHandler('uploadImage', {'localFile':v.localFile,'isShowProgressTips':v.isShowProgressTips}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};
	da.downloadImage = function(v){
		if(this.canTrans())
			djInternal.callHandler('downloadImage', {'picId':v.picId,'isShowProgressTips':v.isShowProgressTips}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};


	da.closeWindow = function(){
		if(this.canTrans())
			djInternal.callHandler('closeWindow');
	};
	da.closeWindowWithMessage = function(v){
		if(this.canTrans())
			djInternal.callHandler('closeWindowWithMessage',{'msg':v.msg});
	};
	da.createWindow = function(v){
		if(this.canTrans())
			djInternal.callHandler('createWindow',{'url':v.url});
	};
	
	da.showMessage = function(v){
		if(this.canTrans())
			djInternal.callHandler('showMessage',{'msg':v.msg,'type':v.type});
	};
	
	da.showPrompt = function(v){
		if(this.canTrans())
			djInternal.callHandler('showPrompt',{'type':v.type});
	};
	da.statusWindow = function(v){
		if(this.canTrans())
			djInternal.callHandler('statusWindow',{'type':v.type,'msg':v.msg});
	};
	da.historyBack = function(){
		if(this.canTrans())
			djInternal.callHandler('historyBack');
	};
	da.appLogin = function(){
		if(this.canTrans())
			djInternal.callHandler('appLogin', {'name':v.name,'pwd':v.pwd,'action':v.action}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};
	da.forward = function(v){
		if(this.canTrans())
			djInternal.callHandler('forward', {'code':v.code}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};
	da.saveFormFeed = function(v){
		if(this.canTrans())
			djInternal.callHandler('saveFormFeed', {'formID':v.formID,'formRecordID':v.formRecordID,'title':v.title}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};
	da.setWebParam = function(v){
		if(this.canTrans())
			djInternal.callHandler('setWebParam', {'title':v.title,'description':v.description,'address':v.address,'picID':v.picID,'logoID':v.logoID,'pageType':v.pageType,'pageID':v.pageID,'isPreview':v.isPreview}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};

	da.requestPortalTopic = function(v){
		if(this.canTrans())
			djInternal.callHandler('requestPortalTopic', {'version':v.version,'isCache':v.isCache}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};

	da.touchPortalTopic = function(v){
		if(this.canTrans())
			djInternal.callHandler('touchPortalTopic', {'tagID':v.tagID});
	};

	da.requestPortalGroup = function(v){
		if(this.canTrans())
			djInternal.callHandler('requestPortalGroup', {'count':v.count,'view':v.view,'style':v.style,'isCache':v.isCache}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};

	da.showGroupList = function(){
		if(this.canTrans())
			djInternal.callHandler('showGroupList');
	};

	da.showGroupSearch = function(){
		if(this.canTrans())
			djInternal.callHandler('showGroupSearch');
	};

	da.requestPortalFeed = function(v){
		if(this.canTrans())
			djInternal.callHandler('requestPortalFeed', {'tagID':v.tagID,'tagName':v.tagName,'count':v.count,'style':v.style,'isCache':v.isCache}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};

	da.requestPortalShop = function(v){
		if(this.canTrans())
			djInternal.callHandler('requestPortalShop', {'tagID':v.tagID,'count':v.count,'isCache':v.isCache, 'rowType': v.rowType},
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};
    da.showProduct = function(v){
        if(this.canTrans())
            djInternal.callHandler('showProduct', {'productID':v.productID});
    };
	da.showFeedDetail = function(v){
		if(this.canTrans())
			djInternal.callHandler('showFeedDetail',{'feedID':v.feedID});
	};

	da.createFeed = function(v){
		if(this.canTrans())
			djInternal.callHandler('createFeed',{'topicID':v.topicID,'tagID':v.tagID});
	};

	da.getPic = function(v){
		if(this.canTrans())
			djInternal.callHandler('getPic',{'picID':v.picID,'size':v.size,'type':v.type}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});
	};
	da.payCheck = function(v){
		if(this.canTrans())
			djInternal.callHandler('payCheck',{'orderID':v.orderID,'merchantId':v.merchantId,'orderAmount':v.orderAmount,'paymentType':v.paymentType,"subject":v.subject,"desc":v.desc}, 
			function (callback){
			  switch(callback.code){
				case 'success':
				  v.success(callback.res);
				break;
				case 'fail':
				  v.fail(callback.res);
				break;
				default:
				  v.fail(callback.res);
				break;
			  }
			});

	};