/*页面级错误提示层，屏幕居中*/

//错误提示层
function mCommon_controlPrompt(promptbox) { //promptbox是错误提示层jq对象

	var promptboxHeight = promptbox.outerHeight();
	var winHeight = $(window).innerHeight();
	var parentPaddingstr = promptbox.parent().css("padding-top");
	var parentPadding = parentPaddingstr.substring(0,parentPaddingstr.length-2);
	var promptboxTop = (winHeight-promptboxHeight)/2-parentPadding;
	
	promptbox.css({"margin-top":promptboxTop})
}
