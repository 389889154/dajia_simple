//loading加载中图层，垂直水平居中。屏幕居中对齐不用写参数，容器居中对齐写参数。
//显示loading层
function mCommon_basicLoadingShow(parentbox){//parentbox是loadingbox的父容器,jq对象
	//loading层结构
	var loadingbox=$("<div class='mCommon_basicLoading'><div class='mCommon_basicLoadingLayerWrapper'><div class='mCommon_basicLoadingLayer'><span class='mCommon_basicLoadingLayer0'><i></i></span><span class='mCommon_basicLoadingLayer5'><i></i></span><span class='mCommon_basicLoadingLayer10'><i></i></span><span class='mCommon_basicLoadingLayer15'><i></i></span><span class='mCommon_basicLoadingLayer20'><i></i></span><span class='mCommon_basicLoadingLayer25'><i></i></span><span class='mCommon_basicLoadingLayer30'><i></i></span><span class='mCommon_basicLoadingLayer35'><i></i></span><span class='mCommon_basicLoadingLayer40'><i></i></span><span class='mCommon_basicLoadingLayer45'><i></i></span><span class='mCommon_basicLoadingLayer50'><i></i></span><span class='mCommon_basicLoadingLayer55'><i></i></span></div></div></div>");
	
	var box;//append dom
	var boxWidth;
	var boxHeight;
	if(parentbox){//容器居中对齐，容器为函数参数
		box=parentbox;
		if(box.height()<60){//如果父容器高度小于loading层的高度，给父容器设置最小高度
			box.css("min-height","80px")
		}
		box.css({"position":"relative"}); 
		boxWidth=box.outerWidth();
		boxHeight=box.outerHeight();		
	}else{//屏幕居中对齐，容器为body
		box=$("body");
		boxWidth=document.documentElement.clientWidth;
		boxHeight=document.documentElement.clientHeight;
		box.css("position","relative");
		loadingbox.css({"position":"fixed"});//loading屏幕居中对齐，不随滚动条滚动
	}
	var loadingTop = (boxHeight - 60)/2;
	var loadingLeft = (boxWidth - 60)/2;
	box.append(loadingbox);
	loadingbox.css({"top":loadingTop,"left":loadingLeft});
}


//删除loading层
function mCommon_basicLoadingRemove(parentbox){
	var box;
	if(parentbox){//容器居中对齐
		box=parentbox;
		box.removeAttr("style"); 	
	}else{//屏幕居中对齐
		box=$("body");
		box.removeAttr("style"); 
	}
	var loadingbox=box.find($(".mCommon_basicLoading"));
	loadingbox.remove();
}