﻿function Web(){
	// 轮播图
	this.PORTALROWTYPE_CAROUSEL_FIGURE = "PORTALROWTYPE_CAROUSEL_FIGURE";
	// 群组列表：垂直
	this.PORTALROWTYPE_LIST_GROUP_VERTICAL = "PORTALROWTYPE_LIST_GROUP_VERTICAL";
	// 群组列表：水平
	this.PORTALROWTYPE_LIST_GROUP_HORIZONTAL = "PORTALROWTYPE_LIST_GROUP_HORIZONTAL";
	// 信息流列表
	this.PORTALROWTYPE_LIST_LOOP = "PORTALROWTYPE_LIST_LOOP";
	// 服务推送：左图
	this.PORTALROWTYPE_LIST_SERVICE_PUSH_LEFT_PICTRUE = "PORTALROWTYPE_LIST_SERVICE_PUSH_LEFT_PICTRUE";
	// 服务推送：右图
	this.PORTALROWTYPE_LIST_SERVICE_PUSH_RIGHT_PICTRUE = "PORTALROWTYPE_LIST_SERVICE_PUSH_RIGHT_PICTRUE";
	// 服务推送：大图
	this.PORTALROWTYPE_LIST_SERVICE_PUSH_BIG_PICTRUE = "PORTALROWTYPE_LIST_SERVICE_PUSH_BIG_PICTRUE";
	// 电商
	this.PORTALROWTYPE_LIST_STORE = "PORTALROWTYPE_LIST_STORE";
	// 新建时空的列表
	this.PORTALROWTYPE_LIST_NULL = "PORTALROWTYPE_LIST_NULL";
	// 下面的菜单 需要跳过
	this.PORTALROWTYPE_BOTTOM_MENU = "";
	this.feedListMap = {
		"PORTALROWTYPE_LIST_LOOP": "PORTALROWTYPE_LIST_LOOP",
		"PORTALROWTYPE_LIST_SERVICE_PUSH_LEFT_PICTRUE": "PORTALROWTYPE_LIST_SERVICE_PUSH_LEFT_PICTRUE",
		"PORTALROWTYPE_LIST_SERVICE_PUSH_RIGHT_PICTRUE": "PORTALROWTYPE_LIST_SERVICE_PUSH_RIGHT_PICTRUE",
		"PORTALROWTYPE_LIST_SERVICE_PUSH_BIG_PICTRUE": "PORTALROWTYPE_LIST_SERVICE_PUSH_BIG_PICTRUE"
	};
	this.newData = null;
	this.topicData = null;
	this.touchClick = false;
}
$
.extend(
	true,
	Web.prototype,
	{
		init: function (){
			var self = this;
			self.initFigure();
			var inDajia = navigator.userAgent.indexOf("dajia") != -1;
			if (inDajia){
				da.ready(function (){
					self.initReady();
				});
				da.error(function (){
					alert("js交互出错啦，请刷新页面！");
				})
				self.findMobileOppoVivo();
			} else {
				self.initReady();
			}
			$(".mCommon_controlPrompt_box").each(function (){
				mCommon_controlPrompt($(this));
			});
		},
		initReady: function (){
			var self = this;
			self.initPic();
			// 请求Feed、Group和shop列表数据
			self.requestFeedAndGroupData(true, true);
			self.initFigureTapEvent();
			self.initTopicTapEvent();
		},
		findMobileOppoVivo: function (obj){
			//oppo和vivo手机，图片边框问题
			var box = $(document);//查找范围
			var userAgentInfo = navigator.userAgent;
			var vivo = "Y13";//oppo的标记
			var oppo = "R831S";//oppo的标记
			if (userAgentInfo.indexOf(oppo) > 0 || userAgentInfo.indexOf(vivo) > 0){ //如果是oppo或vivo,且在app内
				box.find('img').css("border", "1px solid transparent");
			}
		},
		refreshData: function (){
			this.requestFeedAndGroupData(false, true);
		},
		refreshCache: function (){
			this.requestFeedAndGroupData(true, false);
		},
		initPic: function (){
			var self = this;
			$("div[picID]").each(function (){
				var temPicID = $(this).attr("picID");
				if ("defaultPicID" == temPicID) return;
				self.processMethod("getPic", {
					parent: $(this).parent(),
					picID: $(this).attr("picID"),
					size: $(this).attr("picSize") || "1",
					type: $(this).hasClass("mApp_setting_logoWrapper") ? "3" : "0",
					success: function (data){
						var temp = data;
						var picID = temp.picID;
						var url = temp.url;
						$("*[picID='" + picID + "']").css("background-image", "url(" + url + ")");
						setTimeout(function (){
							$("*[picID='" + picID + "']").hide().show();
						}, 500);
					},
					fail: function (data){
					}
				});
			});
			$("img[picID]").each(function (){
				var temPicID = $(this).attr("picID");
				if ("defaultPicID" == temPicID) return;
				self.processMethod("getPic", {
					parent: $(this).parent(),
					picID: $(this).attr("picID"),
					size: "1",
					type: "0",
					success: function (data){
						var temp = data;
						var picID = temp.picID;
						var url = temp.url;
						$("*[picID='" + picID + "']").attr("src", url);
						setTimeout(function (){
							$("*[picID='" + picID + "']").hide().show();
						}, 500);
					},
					fail: function (data){
					}
				});
			});
		},
		initFigure: function (){
			//初始化轮播图的高度和轮播
			$(".mApp_setting_swiperWrapper").each(function (){
				scrollPreviewHeight($(this));
				if ($(this).find(".swiper-slide").length > 1){
					var id = $(this).attr("id");
					var mySwiper = new Swiper("." + id + " .swiper-container", {
						useCSS3Transforms: false,//禁用css动画
						//loopAdditionalSlides:0,//slider增加个数
						speed: 500,
						autoplay: 3000,
						autoplayDisableOnInteraction: false,
						mode: 'horizontal',
						loop: true,
						pagination: '.' + id + ' .pagination',
						paginationClickable: true,
						onSlideChangeEnd: function (){//滚动完成执行
							if (mySwiper.activeLoopIndex == 0){//滚动到第一个
								mySwiper.swipeTo(0, 0);//跳转到第一个
							}
						}
					});
				}
			});
			$(window).resize(function (){
				backgroundImgWidth();
				scrollPreviewHeight($('.mApp_setting_swiperWrapper'));
			});
		},
		initFigureTapEvent: function (){
			var self = this;
			// 轮播图点击事件处理
			$(".swiper-slide > a").unbind().bind("tap", function (){
				var href = $(this).attr("url");
				if (null == href || "" == href){
					return;
				} else {
					self.processMethod("createWindow", {url: href});
				}
			});
		},
		// topic 点击事件注册
		initTopicTapEvent: function (){
			var curSelf = this;
			$("*[portaltype='enter']").each(function (){
				$(this).unbind().bind("tap", function (){
					if (self.touchClick){
						return;
					}
					$(this).find(".mCommon_basicMessageApp").hide();
					var tagID = $(this).attr("tagID");
					if (null == tagID || "" == tagID){
						return;
					}
					self.touchClick = true;
					if ("APPLYELEMENT_GROUP" == tagID
						|| "sm.menu.group" == $(this).attr("uniqueCode")){// 群组入口
						curSelf.processMethod("showGroupList",{"uniqueCode" : $(this).attr("uniqueCode")});
					} else {
						curSelf.processMethod("touchPortalTopic", {
						           tagID: tagID,
						           uniqueCode : $(this).attr("uniqueCode")
						       }
						);
					}
					window.setTimeout("self.touchClick=false;", 1000);
				});
			});
		},
		writePortalGroup: function (res){
			var self = this;
			if (typeof (res) != "object"){
				res = eval('(' + res + ')');
			}
			self.initGroupDataToTemplate(res.data, $("*[portalRowID='" + res.view + "']"), res.style);
			if (self.newData != null && '' != self.newData){
				self.initNewGroupDataToTemplate(self.newData.group, false);
			}
		},
		initGroupDataToTemplate: function (groupContent, line, lineType){
			var self = this;
			var lineDemoBox = $("*[demo='line']");
			var showGroupListDiv;
			showGroupListDiv = line.parent().parent().find(".mCommon_basicListMore");
			if (lineType == self.PORTALROWTYPE_LIST_GROUP_HORIZONTAL){
				line.find("*[enterType='horizontalGroup']").each(function (){
					$(this).children().remove();
				});
			} else {
				line.children().remove();
			}
			if (null != groupContent && groupContent.length > 0){
				line.show();
				showGroupListDiv.show();
				line.parent().find("#_common_no_content_template").hide();
				// 注册 更多 按钮点击事件
				showGroupListDiv.unbind().bind("tap", function (){
					self.processMethod("showGroupList",{"uniqueCode" : line.attr("uniqueCode")
					    
					});
				});
				for (var i = 0; i < groupContent.length; i++) {
					var groupData = groupContent[i];
					if (null != groupData){
						var group_template = lineDemoBox.find("*[itemType=" + lineType + "]").clone();
						group_template.find("#_group_logo").attr("picID", groupData.groupID);
						group_template.attr("groupID", groupData.groupID);
						if (lineType == self.PORTALROWTYPE_LIST_GROUP_VERTICAL){
							if (groupData.groupName){
								group_template.find(".groupName").html(groupData.groupName);
							} else {
								group_template.find(".groupName").html("");
							}
							var publishPersonName = groupData.publishPersonName;
							var groupFeedContent = groupData.content;
							if (!publishPersonName){
								publishPersonName = "";
							}
							if (!groupFeedContent){
								groupFeedContent = "";
							}
							if ("" == publishPersonName && groupFeedContent == ""){
								group_template.find(".feedDetail").html("");
							} else {
								group_template.find(".feedDetail").html(
									publishPersonName + " : " + groupFeedContent);
							}
							self.initGroupTapEvent(group_template, groupData.groupID, groupData.groupName);
							line.append(group_template);
							self.processMethod("getPic", {
								parent: line,
								picID: groupData.groupID || "",
								size: "1",
								type: "2",
								success: function (data){
									var temp = data;
									var picID = temp.picID;
									var url = temp.url;
									var temPicID = $(this).attr("picID");
									if (temPicID == picID){
										$("*[portalRowType='PORTALROWTYPE_LIST_GROUP_VERTICAL']").find("*[picID='" + picID + "']").attr(
											"src", url);
									}
								},
								fail: function (data){
								}
							});
						} else if (lineType == self.PORTALROWTYPE_LIST_GROUP_HORIZONTAL){
							if (i > 2){
								break;
							}
							if (groupData.groupName){
								group_template.find(".groupContent").html(groupData.groupName.subCHStr(0, 20));
							} else {
								group_template.find(".groupContent").html("");
							}
							self.initGroupTapEvent(group_template, groupData.groupID, groupData.groupName);
							line.find("*[enterType='horizontalGroup']")
							.eq(i).append(group_template);
							self.processMethod("getPic", {
								parent: line,
								picID: groupData.groupID || "",
								size: "1",
								type: "2",
								success: function (data){
									var temp = data;
									var picID = temp.picID;
									var url = temp.url;
									var temPicID = $(this).attr("picID");
									if (temPicID == picID){
										$("*[portalRowType='PORTALROWTYPE_LIST_GROUP_HORIZONTAL']").find("*[picID='" + picID + "']").attr(
											"src", url);
									}
								},
								fail: function (data){
								}
							});
						}
					}
				}
				if (lineType == self.PORTALROWTYPE_LIST_GROUP_HORIZONTAL && 0 < groupContent.length < 3){
					self.transConstractHorizontalGroup(line);
				}
			} else {
				// 重新 构造 空提示
				self.initNoGroupRow(line);
				// 控制 更多 显示按钮
				showGroupListDiv.hide();
				return;
			}
		},
		transConstractHorizontalGroup: function (line){
			var self = this;
			line.find("*[enterType='horizontalGroup']").each(
				function (i){
					if (null == $(this).html() || $(this).html() == ""){
						var hor_template = $("*[demo='line']").find("*[itemType=" + self.PORTALROWTYPE_LIST_GROUP_HORIZONTAL + "]").clone();
						hor_template.find(".mCommon_controlListBlockListGroup2_imgAndInfo").hide();
						$(this).append(hor_template);
					}
				})
		},
		initGroupTapEvent: function (group_template, groupID, groupName){
			var self = this;
			group_template.unbind().bind("tap", function (){
				$(this).find(".mCommon_basicMessageList").hide();
				if (window.self.touchClick){
					return;
				}
				window.self.touchClick = true;
				self.processMethod("showGroup", {
					groupID: groupID,
					groupName: groupName
				});
				window.setTimeout("window.self.touchClick=false;", 2000);
			});
		},
		writePortalProduct: function (res){
			var self = this;
			if (typeof (res) != "object"){
				res = eval('(' + res + ')');
			}
			if (res && res.data){
				self.initProductDataToTemplate(res.data, $("*[companyMenuID='" + res.tagID + "']"), res.rowType, res.tagID);
			}
		},
		initProductDataToTemplate: function (productList, line, lineType, tagID){
			var self = this;
			if (!productList || productList.length == 0){
				line.parent().parent().find(".mCommon_basicListMore").hide();
				self.initNoProductRow(line);
			} else {
				var lineBoxForClone = $("*[demo='line']");
				line.parent().find("#_common_no_content_template").hide();
				line.children().remove();
				for (var i = 0; i < productList.length; i++) {
					var productData = productList[i];
					var productItem = lineBoxForClone.find("*[itemType=" + lineType + "]").clone();
					productItem.find(".mCommon_basicShopItemPortal_info > h3").html(productData.name.subCHStr(0, 44));
					var priceStr = "";
					if (productData.price){
						priceStr += productData.price;
					}
					if (productData.unit){
						priceStr += "<em>/" + productData.unit + "</em>";
					}
					productItem.find(".mCommon_basicShopItemPortal_info .mCommon_basicShopItemPortal_money > span").html(priceStr);

					var distance = "";
					if (productData.distance && 'null' != productData.distance){
						distance = productData.distance;
					}
					productItem.find(".mCommon_basicShopItemPortal_info > .mCommon_basicShopItemPortal_distance").html(distance);
					productItem.data("productData", productData);
					productItem.find("#product_pic").attr("picID", productData.logo);
					productItem.unbind().bind("tap", function (){
						var productData = $(this).data("productData");
						self.processMethod("showProduct", {productID: productData.productID});
					});
					line.append(productItem);
					self.processMethod("getPic", {
						parent: line,
						picID: productData.logo || "",
						size: "1",
						type: "0",
						success: function (data){
							var temp = data;
							var picID = temp.picID;
							var url = temp.url;
							var temPicID = $(this).attr("picID");
							if (temPicID == picID){
								line.find("*[picID='" + picID + "']").attr(
									"src", url);
							}
						},
						fail: function (data){
						}
					});
				}
				line.parent().parent().find(".mCommon_basicListMore").show();
				line.parent().parent().find(".mCommon_basicListMore").unbind().bind("tap", function (){
					self.processMethod("touchPortalTopic", {tagID: tagID});
				});
			}
		},
		processMethod: function (method, paramObj){
			var obj;
			if (da.djJsReady){
				obj = da;
			} else {
				obj = dw;
			}
			obj[method](paramObj);
		},
		writePortalFeed: function (res){
			var self = this;
			if (typeof (res) != "object"){
				res = eval('(' + res + ')');
			}
			self.initFeedDataToTemplate(res.data, $("*[companyMenuID='" + res.tagID + "']"), res.style,
				res.tagID);
		},
		initFeedDataToTemplate: function (feedDataList, line, lineType, tagID){
			var lineBoxForClone = $("*[demo='line']");
			var self = this;
			line.children().remove();
			if (null == feedDataList || feedDataList.length <= 0){
				self.initNoFeedRow(line);
				line.parent().parent().find(".mCommon_basicListMore").hide();
			} else {
				line.parent().parent().find(".mCommon_basicListMore").unbind().bind("tap", function (){
					self.processMethod("touchPortalTopic", {tagID: tagID, uniqueCode : line.attr("uniqueCode")});
				});
				line.parent().find("#_common_no_content_template").hide();
				line.parent().parent().find(".mCommon_basicListMore").show();
				for (var i = 0; i < feedDataList.length; i++) {
					var feedData = feedDataList[i];
					if (null != feedData){
						if (lineType == self.PORTALROWTYPE_LIST_LOOP){
							var list_loop_template = lineBoxForClone.find("*[itemType=" + lineType + "]").clone();
							list_loop_template.find("#person_pic").attr("picID", feedData.personID);
							var content = feedData.personName + " : " + feedData.content;
							if (content){
								list_loop_template.find("#_feed_content").html(content.subCHStr(0, 20));
							} else {
								list_loop_template.find("#_feed_content").html("");
							}
							list_loop_template.attr("uniqueCode", line.attr("uniqueCode"));
							self.initPortalFeedTapEvent(list_loop_template, feedData.feedID);
							line.append(list_loop_template);
							self.processMethod("getPic", {
								parent: list_loop_template,
								picID: feedData.personID || "",
								size: "1",
								type: "1",
								success: function (data){
									var temp = data;
									var picID = temp.picID;
									var url = temp.url;
									var temPicID = $(this).attr("picID");
									if (temPicID == picID){
										line.find("*[picID='" + picID + "']").attr("src", url);
									}
								},
								fail: function (data){
								}
							});
						} else {
							var common_feed_list_template = "";
							var scale = 107 / 80;
							common_feed_list_template = lineBoxForClone.find("*[itemType=" + lineType + "]").clone();
							var strTitleCount = 38;
							var strContentCount = 52;
							if (lineType == self.PORTALROWTYPE_LIST_SERVICE_PUSH_BIG_PICTRUE){
								scale = 580 / 380;
								strTitleCount = 66;
								strContentCount = 90;
							}
							common_feed_list_template.find("#_face_pic").attr("picID", feedData.picID);
							if (feedData.title){
								common_feed_list_template.find("#_feed_title").html(feedData.title.subCHStr(0, strTitleCount));
							} else {
								common_feed_list_template.find("#_feed_title").html("");
							}
							if (feedData.content){
								common_feed_list_template.find("#_feed_content").html(feedData.content.subCHStr(0, strContentCount));
							} else {
								common_feed_list_template.find("#_feed_content").html("");
							}
							//小邻通定制
							common_feed_list_template.find("#_feed_read_num").parent().parent().parent().hide();
							common_feed_list_template.find("#_feed_publish_time").html(feedData.date);
							common_feed_list_template.find("#_feed_read_num").html(feedData.readNum);
							common_feed_list_template.find("#_feed_comments_num").html(feedData.commentNum);
							common_feed_list_template.find("#_feed_praise_num").html(feedData.praiseNum);
							common_feed_list_template.attr("uniqueCode",line.attr("uniqueCode"));
							self.initPortalFeedTapEvent(common_feed_list_template, feedData.feedID);
							line.append(common_feed_list_template);
							self.processMethod("getPic", {
								parent: common_feed_list_template,
								picID: feedData.picID || "",
								size: "3",
								type: "0",
								scale: scale,
								success: function (data){
									var temp = data;
									var picID = temp.picID;
									var url = temp.url;
									var temPicID = $(this).attr("picID");
									if (temPicID == picID){
										line.find("*[picID='" + picID + "']").attr("src", url);
									}
									var box = $(line.find("*[picID='" + picID + "']").parent());
									mImgCut(box, scale);
								},
								fail: function (data){
								}
							});
						}
					}
				}
			}
		},
		initPortalFeedTapEvent: function (template, feedID){
			var curSelf = this;
			template.unbind().bind("tap", function (){
				if (window.self.touchClick){
					return;
				}
				window.self.touchClick = true;
				curSelf.processMethod("showFeedDetail", {
					feedID: feedID,
					uniqueCode : $(this).attr("uniqueCode")
				});
				window.setTimeout("window.self.touchClick=false;", 2000);
			});
		},
		initNoProductRow: function (line){
			line.children().remove();
			line.parent().find("#_common_no_content_template").show();
			line.parent().find("#_tip_content").show();
			line.parent().find("#_tip_content").html("还没商品!");
			line.parent().find("#_btn_content").hide();
		},
		initNoGroupRow: function (line){
			var self = this;
			line.hide();
			line.parent().find("#_common_no_content_template").show();
			line.parent().find("#_tip_content").show();
			line.parent().find("#_tip_content").html("还没加入任何群");
			line.parent().find("#_btn_content").html("找些有兴趣的群").unbind().bind("tap", function (){
				self.processMethod("showGroupSearch",{uniqueCode : line.attr("uniqueCode")});
			});
		},
		initNoFeedRow: function (line){
			//var line = $("*[tagID_feng='" + tagID + "']");
			//line.append(tagID);
			//var group_null_template = line.find("#_common_no_content_template");
			//group_null_template.show();
			//line.find("#_tip_content").html(tagID);
			var self = this;
			line.children().remove();
			line.parent().find("#_common_no_content_template").show();
			if (line.attr("right_send") == "SEND" && line.attr("uniqueCode") != "sm.menu.blog"){
				line.parent().find("#_tip_content").hide();
				line.parent().find("#_btn_content").html("抢头条").show();
				line.parent().find("#_btn_content").unbind().bind("tap",
					function (){
						self.processMethod("createFeed", {
							topicID: line.attr("topicPresetID"),
							tagID: line.attr("companyMenuID")
						});
					});
			} else {
				line.parent().find("#_tip_content").html("期待内容").show();
					line.parent().find("#_btn_content").hide();
			}
		},
		initErrorGroupRow: function (line, style, isCache){
			var self = this;
			line.children().remove();
			var group_error_template = $("*[demo='line']").find("#_common_error_template").clone();
			group_error_template.show();
			group_error_template.find("#_btn_content").unbind().bind("tap", function (){
				self.initNoGroupRow(line);
				self.requestPortalGroup(line.attr("count"), line.attr("portalRowID"), style, isCache);
			});
			line.append(group_error_template);
		},
		initErrorFeedRow: function (line, isCache){
			var self = this;
			line.children().remove();
			var feed_error_template = $("*[demo='line']").find("#_common_error_template").clone();
			feed_error_template.find("#_btn_content").unbind().bind(
				"tap",
				function (){
					self.initNoFeedRow(line);
					self.requestPortalFeed(line.attr("portalRowID"), line.attr("title"), line
					.attr("count"), line.attr("portalRowType"), isCache);
				});
			line.append(feed_error_template);
		},
		initErrorProductRow: function (line){
			var self = this;
			line.children().remove();
			var feed_error_template = $("*[demo='line']").find("#_common_error_template").clone();
			feed_error_template.find("#_btn_content").unbind().bind(
				"tap",
				function (){
					self.initNoProductRow(line);
					self.requestPortalShop(line.attr("portalRowID"), line.attr("count"), line.attr("portalRowType"));
				});
			line.append(feed_error_template);
		},
		// 清理未读标记
		clearNew: function (){
			var self = this;
			$(".mCommon_basicMessageApp").hide();
			$(".mCommon_basicMessageList").hide();
			self.newData = null;
		},
		// 未读数据回填
		writeNew: function (res){
			var self = this;
			if (typeof (res) != "object"){
				res = eval('(' + res + ')');
			}
			self.newData = res;
			self.initNewDataToTemplate(res, true);
		},
		initNewDataToTemplate: function (unReadData, needNet){
			var self = this;
			if (null == unReadData || '' == unReadData)
				return;
			$(".mCommon_basicMessageApp").hide();
			var conBox = $(".mApp_setting");// 写入内容的区域
			var topicPresetList = unReadData.topicPreset;
			if (null != topicPresetList && topicPresetList.length > 0){
				for (var i = 0; i < topicPresetList.length; i++) {
					var topicPreset = topicPresetList[i];
					if (topicPreset.count == 0)
						continue;
					if (needNet){
						conBox.find("*[portalRowID='" + topicPreset.tagID + "']").each(function (){
							self.requestPortalFeed($(this).attr("portalRowID"), $(this).attr("title"), // 主题名称
								$(this).attr("count"), $(this).attr("portalRowType"), false);
						});
					}
					conBox.find("*[tagID='" + topicPreset.tagID + "']")
					.find(".mCommon_basicMessageApp").show();
					conBox.find("*[tagID='" + topicPreset.tagID + "']")
					.find(".mCommon_basicMessageApp").html(topicPreset.count);
				}
			}
			self.initNewGroupDataToTemplate(unReadData.group, needNet);
		},
		initNewGroupDataToTemplate: function (groupList, needNet){
			var self = this;
			$(".mCommon_basicMessageList").hide();
			if (null != groupList && groupList.length > 0){
				var count = 0;
				var conBox = $(".mApp_setting");// 写入内容的区域
				for (var i = 0; i < groupList.length; i++) {
					var group = groupList[i];
					count = count + group.count || 0;
					if (conBox.find("*[groupID='" + group.tagID + "']")){
						if (group.count == 0){
							conBox.find("*[groupID='" + group.tagID + "']").find(".mCommon_basicMessageList")
							.hide();
						} else {
							conBox.find("*[groupID='" + group.tagID + "']").find(".mCommon_basicMessageList")
							.show();
						}
					}
				}
				if (count > 0 && needNet){
					conBox.find("*[portalRowType='PORTALROWTYPE_LIST_GROUP_HORIZONTAL'], *[portalRowType='PORTALROWTYPE_LIST_GROUP_VERTICAL']").each(
						function (){
							self.requestPortalGroup($(this).attr("count"), $(this).attr("portalRowID"),
								$(this).attr("portalRowType"), false);
						});
				}
			}
		},
		requestFeedAndGroupData: function (isCache, ifCacheNeedRefresh){
			var self = this;
			var conBox = $(".appBox");// 写入内容的区域
			// 只请求列表数据
			conBox.find(".feed_list").each(function (){
				if (self.PORTALROWTYPE_LIST_GROUP_VERTICAL == $(this).attr("portalRowType")
					|| self.PORTALROWTYPE_LIST_GROUP_HORIZONTAL == $(this).attr("portalRowType")){
					self.requestPortalGroup($(this).attr("count"), $(this).attr("portalRowID"),
						$(this).attr("portalRowType"), isCache);
				} else if (self.PORTALROWTYPE_LIST_STORE == $(this).attr("portalRowType")){
					var companyMenuID = $(this).attr("companyMenuID");
					if (companyMenuID == null || '' == companyMenuID) return;
					self.requestPortalShop(companyMenuID, $(this).attr("count"),
						$(this).attr("portalRowType"), isCache);
				} else {
					var companyMenuID = $(this).attr("companyMenuID");
					if (companyMenuID == null || '' == companyMenuID) return;
					self.requestPortalFeed(companyMenuID, $(this).attr("title"), $(this)
					.attr("count"), $(this).attr("portalRowType"), isCache);
				}
			});
			if (isCache && ifCacheNeedRefresh){
				self.requestFeedAndGroupData(false, true);
			}
		},
		requestPortalGroup: function (count, view, style, isCache){
			var self = this;
			var requestData = {
				count: count, // 数量
				view: view, // 位置
				style: style, // 样式
				isCache: isCache, // 是否使用缓存
				success: function (res){
					self.writePortalGroup(res);
				},
				fail: function (res){
					if (typeof (res) != "object"){
						res = eval('(' + res + ')');
					}
					self.initErrorGroupRow($("*[portalRowID='" + res.view + "']"), res.style, res.isCache);
				}
			};
			self.processMethod("requestPortalGroup", requestData);
		},
		requestPortalFeed: function (tagID, tagName, count, style, isCache){
			var self = this;
			var requestData = {
				tagID: tagID, // 主题ID
				tagName: tagName, // 主题名称
				count: count, // 数量（默认为3）
				style: style, // 显示样式
				isCache: isCache, // 是否使用缓存
				success: function (res){
					self.writePortalFeed(res);
				},
				fail: function (res){
					if (typeof (res) != "object"){
						res = eval('(' + res + ')');
					}
					self.initErrorFeedRow($("*[portalRowID='" + res.tagID + "']"), isCache);
				}
			};
			self.processMethod("requestPortalFeed", requestData);
		},
		requestPortalShop: function (tagID, count, rowType, isCache){
			var self = this;
			var requestData = {
				count: count,
				tagID: tagID,
				rowType: rowType,
				isCache: isCache, // 是否使用缓存
				success: function (res){
					self.writePortalProduct(res);
				},
				error: function (res){
					self.initErrorProductRow($("*[companyMenuID='" + res.tagID + "']"));
				}
			};
			self.processMethod("requestPortalShop", requestData);
		}
	});
