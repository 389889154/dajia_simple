
/*点击改变样式===================
    自动执行；
    页面使用<p class="mCommon" tapClass="mCommonTapClass">点击查看效果</p>
    页面上移动有"tapClass"属性的元素，
    tap时添加"tapClass"的样式，
    过一会样式消失；
    */
function mCommonTapClass(obj) {//参数是查找范围 jq对象，默认是document
	var box=$(document);//查找范围
	if(obj!=null&&obj!=""){//如果obj有参数
		box=obj;//查找范围是obj
	}
	var tapItem=box.find("*[tapClass]");//点击的对象
	if(tapItem.length==0){//范围内没有tapClass
		return false;
	}
	tapItem.css("-webkit-tap-highlight-color","rgba(0,0,0,0)");//去掉默认的相应
    tapItem.tap(function () {
        var self = $(this);
        var timeOut = 500;//延时
        var tapClass = self.attr("tapClass");
        if (tapClass == "" || tapClass == null) {
            self.css("background-color", "#e5e5e5");
            setTimeout(function () { self.css("background-color", ""); }, timeOut);
        } else {
            self.addClass(tapClass);
            setTimeout(function () { self.removeClass(tapClass) }, timeOut);
        }


        });
}

//按钮阻止冒泡
function mCommonBtnStopPropagation(obj) {//参数是查找范围 jq对象，默认是document
	var box=$(document);//查找范围
	if(obj!=null&&obj!=""){//如果obj有参数
		box=obj;//查找范围是obj
	}
	var tapBtn=box.find(".mCommon_basicBtn,.mCommon_basicBtn32");//点击的对象
	if(tapBtn.length==0){//范围内没有tapClass
		return false;
	}
    tapBtn.tap(function(event){
		 event.stopPropagation(); 
	})
 
}

//自动执行匿名函数
(function () {
    $().ready(function () {
        mCommonTapClass();
        mCommonBtnStopPropagation();//给所有按钮阻止冒泡
    });
})();

/*点击改变样式 end*/


/*页面最小高度=========================*/

function mCommonPageMiniHeight(obj, headH, footH, otherH) {//obj:加最小高的jq对象,headH:头部高度,footH:底部高度,otherH:其他高度如padding/margin
        if (headH == "" || headH == null) { headH = 0 };
        if (footH == "" || footH == null) { footH = 0 };
        if (otherH == "" || otherH == null) { otherH = 0 };
        function minHeight() {
            var WH = $(window).height();
            var minH = WH - headH - footH - otherH;
            obj.css("min-height", minH);
        };

        minHeight();//执行
        $(window).resize(function () {
            minHeight();
        });
}
/*页面最小高度end*/

/*判断微信==================*/
function isWeiXin() {//返回true/false
        var ua = window.navigator.userAgent.toLowerCase();
        if (ua.match(/MicroMessenger/i) == 'micromessenger') {
            return true;
        } else {
            return false;
        }
}
/*判断微信end*/


/*判断是否为移动端==================*/
function isMobile(){//返回true/false
        var userAgentInfo = navigator.userAgent;
        /*var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod");*/
        var Agents = new Array("Android", "iPhone");
        var flag = false;
        for (var v = 0; v < Agents.length; v++) {
            if (userAgentInfo.indexOf(Agents[v]) >= 0) { flag = true; return flag; }
        }
        return flag;
}
/*判断是否为移动端end*/

/*根据浏览器 给 body 加 class 自动执行==================*/
(function () {
        function browser() {//移动端 body标签写入 class="Android"/ "iPhone"
            var userAgentInfo = navigator.userAgent;
            /*var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod");*/
            var Agents = new Array("Android", "iPhone");
            for (var v = 0; v < Agents.length; v++) {
                if (userAgentInfo.indexOf(Agents[v]) >= 0) {
                    $("body").addClass(Agents[v]);
                    return;
                }
            }
        }
        $().ready(function () {
            browser();
        });
    })();
/*根据浏览器 给 body 加 class end==================*/

/*解决三星note2 数字键盘没有小数点================*/
function mCommon20150221_note2NumInput(obj) {//参数是查找范围 jq对象，默认是document
	var box=$(document);//查找范围
	if(obj!=null&&obj!=""){//如果obj有参数
		box=obj;//查找范围是obj
	}
	var userAgentInfo = navigator.userAgent;
	var note2="GT-N7108";//note的标记
	var qqBrowser="MQQBrowser";//qq浏览器
	if (userAgentInfo.indexOf(note2)>0 && userAgentInfo.indexOf(qqBrowser)<0){ //如果是note2,且不是qq浏览器
			box.find('input[type="number"]').attr("type","text");
	}
}
$().ready(function(){
	mCommon20150221_note2NumInput();
});
/*解决三星note2 数字键盘没有小数点 end================*/


