(function (owner) {
    owner.requestPortalFeed = function(requestData) {
        if (requestData.isCache) {
            // PC加载缓存的处理
            return;
        }
        $.ajax({
            url : _ctxPath + "/mobilemainpageforthirdparty/getPortalFeed.json",
            type : "post",
            data : {
                page : 1,
                count : requestData.count,
                tagID : requestData.tagID,
                companyID : $("#currentCompanyID").val()
            },
            success : function(resultData) {
                var res = {};
                res.tagID = requestData.tagID;
                res.style = requestData.style;
                res.data = resultData.page.dataList;
                requestData.success(res);
            },
            error : function() {
                console.info("error");
                var res = {};
                res.tagID = requestData.tagID;
                res.style = requestData.style;
                requestData.fail(res);
            }
        });
    };

    owner.requestPortalGroup = function(requestData) {
        $.ajax({
            url : _ctxPath + "/mobilemainpageforthirdparty/getPortalGroup.json",
            type : "post",
            data : {
                pageSize : requestData.count
            },
            success : function(resultData) {
                var res = {};
                res.style = requestData.style;
                res.view = requestData.view;
                res.data = resultData.homeGroupList;
                requestData.success(res);
            },
            error : function() {
                var res = {};
                res.style = requestData.style;
                res.view = requestData.view;
                requestData.fail(res);
            }
        });
    };

    owner.requestPortalShop = function(requestData) {
        $.ajax({
            url : _ctxPath + "/mobilemainpageforthirdparty/getPortalShop.json",
            type : "post",
            data : {
                companyMenuID : requestData.tagID,
                page : 1,
                count : requestData.count
            },
            success : function(resultData) {
                var res = {};
                res.tagID = requestData.tagID;
                res.rowType = requestData.rowType;
                res.data = resultData.page.dataList;
                requestData.success(res);
            },
            error : function() {
                var res = {};
                res.tagID = requestData.tagID;
                res.rowType = requestData.rowType;
                requestData.error(res);
            }
        });
    };
    owner.showProductList = function(requestData) {
        ppm.transRequestService(requestData.uniqueCode,requestData.tagID);
    };
    owner.showProduct = function(requestData) {
        window.open(_ctxPath + "/mobileproduct/findProductIndex.action?productId=" + requestData.productID);
    };
    owner.createWindow = function(requestData) {
        window.location.href = requestData.url;
    };
    owner.showGroupList = function(requestData) {
        ppm.transRequestService(requestData.uniqueCode,requestData.tagID);
    };
    owner.touchPortalTopic = function(requestData){
        ppm.transRequestService(requestData.uniqueCode,requestData.tagID);
    };
    owner.showGroup = function(requestData) {
        ppm.transRequestService(requestData.uniqueCode,requestData.tagID);
    };
    owner.showFeedDetail = function(requestData) {
        if(ppm.html5MapArray[requestData.uniqueCode]){
            var url = _ctxPath + "/r/mp/richtext/"+$("#currentCompanyID").val()+"/"+requestData.feedID;
            window.location.href = url;
            return;
        }
        ppm.transRequestService(requestData.uniqueCode,requestData.tagID);
    };
    owner.showGroupSearch = function(requestData) {
        ppm.transRequestService(requestData.uniqueCode,requestData.tagID);
    };
    owner.createFeed = function(requestData){
        ppm.transRequestService(requestData.uniqueCode,requestData.tagID);
    };
    owner.getPic = function(requestData) {
        var parent = requestData.parent;
        var picType = requestData.type;
        var picSize = requestData.size||"1";
        var picUrl;
        if (requestData.picID) {
            var sizeParam = "";
            if(picSize=="3"){//中图
                sizeParam = "&show=middle";
            }else if(picSize=="2"){//大图
                sizeParam = "&show=big";
            }
            if ("0" == picType) { // 普通图片
                picUrl = _ctxPath + "/file/loadPic.img?id=" + requestData.picID+sizeParam;
            } else if ("1" == picType) { // 人员
                picUrl = _ctxPath + "/file/loadPic.img?personID=" + requestData.picID+sizeParam;
            } else if ("2" == picType) { // 群组
                picUrl = _ctxPath + "/file/loadPic.img?groupID=" + requestData.picID+sizeParam;
            } else if ("3" == picType) { // 社区
                picUrl = _ctxPath + "/file/loadPic.img?id=" + requestData.picID+sizeParam;
            }
            var ele = parent.find("*[picID='" + requestData.picID + "']");
            if(ele) {
                var tagName = ele[0].tagName || "";
                if (tagName == "DIV") {
                    ele.css("background-image","url(" + picUrl + ")");
                }else{
                    ele.attr("src", picUrl);
                }
            }
            if (picUrl && requestData.scale) {
                var box = $(parent.find("*[picID='" + requestData.picID + "']").parent());
                mImgCut(box, requestData.scale);
            }
        }

    }
})(dw = {});

