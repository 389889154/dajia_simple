function PortalPcManage(option) {
    this.setting = {
            // 是否微信
            isInWeixin : false,
            currentCompanyID : "",
            currentPersonID : "",
            isCanImportCommodity : true,
            url : ""
    };
    // 已经html5化列表
    this.html5MapArray = {
        // 会员经营分析
        "statistical_analysis" : {
            "weixinCanUse" : true,
            "thirdPartyCanUse" : true
        },
        // 外部链接
        "sm.menu.link" : {
            "weixinCanUse" : true,
            "thirdPartyCanUse" : true
        },
        // 移动网页
        "mobileportal" : {
            "weixinCanUse" : true,
            "thirdPartyCanUse" : true
        },
        // 店铺
        "store.menu.shopping" : {
            "weixinCanUse" : true,
            "thirdPartyCanUse" : true
        },
        "sm.menu.richtext" : {
            "weixinCanUse" : true,
            "thirdPartyCanUse" : true
        },
        "shareInfo" : {
            "weixinCanUse" : true,
            "thirdPartyCanUse" : true
        },
        "sm.menu.mobile.photograph" : {
            "weixinCanUse" : true,
            "thirdPartyCanUse" : true
        },
        "sm.menu.mobile.location" : {
            "weixinCanUse" : true,
            "thirdPartyCanUse" : true
        },
        "sm.menu.mobile.record" : {
            "weixinCanUse" : true,
            "thirdPartyCanUse" : true
        },
//        // 信息流列表
//        "PORTALROWTYPE_LIST_LOOP" : {
//            "weixinCanUse" : true,
//            "thirdPartyCanUse" : true
//        },
//        // 群组列表：垂直
//        "PORTALROWTYPE_LIST_GROUP_VERTICAL" : {
//            "weixinCanUse" : true,
//            "thirdPartyCanUse" : true
//        },
//        // 群组列表：水平
//        "PORTALROWTYPE_LIST_GROUP_HORIZONTAL" : {
//            "weixinCanUse" : true,
//            "thirdPartyCanUse" : true
//        },
//        // 服务推送：左图
//        "PORTALROWTYPE_LIST_SERVICE_PUSH_LEFT_PICTRUE" : {
//            "weixinCanUse" : true,
//            "thirdPartyCanUse" : true
//        },
//        // 服务推送：右图
//        "PORTALROWTYPE_LIST_SERVICE_PUSH_RIGHT_PICTRUE" : {
//            "weixinCanUse" : true,
//            "thirdPartyCanUse" : true
//        },
//        // 服务推送：大图
//        "PORTALROWTYPE_LIST_SERVICE_PUSH_BIG_PICTRUE" : {
//            "weixinCanUse" : true,
//            "thirdPartyCanUse" : true
//        },
        // 电商
        "PORTALROWTYPE_LIST_STORE" : {
            "weixinCanUse" : true,
            "thirdPartyCanUse" : true
        },
        // 手机官网
        "mobileportal" : {
            "weixinCanUse" : true,
            "thirdPartyCanUse" : true
        },
        "sm.menu.mobile.phone" : {
            "weixinCanUse" : true,
            "thirdPartyCanUse" : true
        }
    };
    this.joinCompanyUrl = _ctxPath + "/m/joinCompany.action";
    this.registerJoinCompanyUrl = _ctxPath + "/m/goToTwoDimensionCodeRegister.action";
    this.wakeUpAppUrl = _ctxPath + "/m/ccapp.action";
    this.weixinJoinCompanyUrl = _ctxPath + "/m/perJoinCompanyInWeChat.action";
    this.LOGINED_JOINED_NATIVE_CONTENT = "该应用仅支持在APP中查看";
    this.LOGINED_UNJOINED_NONATIVE_CONTENT = "加入社区后才能操作现在加入社区？";
    this.LOGINED_UNJOINED_NATIVE_CONTENT = "加入社区并前往APP才能继续访问内容";
    this.VIPCOMPANY_CONENT = "该应用暂不支持访问";
    $.extend(true,this.setting,option);
    this.init();

}
$.extend(true, PortalPcManage.prototype, {
    init : function() {

    },
    // 构造url
    constructUrl : function(url,callbackUrl){
        var self = this;
        var sourceUrl = url;
        if(sourceUrl.indexOf("?") > -1){
            if(sourceUrl.indexOf("?") != (sourceUrl.length - 1)){
                sourceUrl = sourceUrl + "&cID="+self.setting.currentCompanyID;
            }else{
                sourceUrl = sourceUrl + "cID="+self.setting.currentCompanyID;
            }
        }else{
            sourceUrl = sourceUrl + "?cID="+self.setting.currentCompanyID;
        }
        if(self.setting.currentPersonID){
            sourceUrl = sourceUrl + "&pID=" + self.setting.currentPersonID;
        }
        if(callbackUrl){
            sourceUrl = sourceUrl + "&portalUrl=" + callbackUrl;
        }
        return sourceUrl;
    },
    // 获取第三方访问信息
    // 需要判断人员状态的应用访问
    getThirdPartyInfo : function(param,url){
        var self = this;
        $.ajax({
            url : _ctxPath + "/mobilemainpageforthirdparty/getThirdPartyInfo.json",
            type : "post",
            data : {
                companyID : self.setting.currentCompanyID
            },
            success : function(resultData) {
                var isLogined = resultData.isLogined;
                var personCompanyStatus = resultData.personCompanyStatus;
                self.setting.isInWeixin = resultData.thirdPartyMap.inWeixin == "true"?true:false;
                self.setting.currentPersonID = resultData.currentPersonID;
                var content = "";
                var sourceUrl = "";
                if(param){//已H5化的应用
                    if(param.thirdPartyCanUse){
                        sourceUrl = self.constructUrl(url);
                        window.location.href = sourceUrl;
                        return;
                    }else if("true" == isLogined){
                        if(0 == personCompanyStatus){
                            sourceUrl = self.constructUrl(url);
                            window.location.href = sourceUrl;
                            return;
                        }else{
                            content = self.LOGINED_UNJOINED_NONATIVE_CONTENT;
                            if(self.setting.isInWeixin){
                                sourceUrl = self.constructUrl(self.weixinJoinCompanyUrl,url);
                            }else{
                                sourceUrl = self.constructUrl(self.joinCompanyUrl,url);
                            }
                        }
                    }else{
                        content = self.LOGINED_UNJOINED_NONATIVE_CONTENT;
                        if(self.setting.isInWeixin){
                            sourceUrl = self.constructUrl(self.weixinJoinCompanyUrl,url);
                        }else{
                            sourceUrl = self.constructUrl(self.registerJoinCompanyUrl,url);
                        }
                    }
                }else{//未H5化的应用
                    if(self.setting.isCanImportCommodity == "false"){
                        alert(self.VIPCOMPANY_CONENT);
                        return;
                    }
                    if("true" == isLogined){
                        if(0 == personCompanyStatus){
                            content = self.LOGINED_JOINED_NATIVE_CONTENT;
                            sourceUrl = self.constructUrl(self.wakeUpAppUrl);
                        }else{
                            content = self.LOGINED_UNJOINED_NATIVE_CONTENT;
                            if(self.setting.isInWeixin){
                                sourceUrl = self.constructUrl(self.weixinJoinCompanyUrl,url);
                            }else{
                                sourceUrl = self.constructUrl(self.joinCompanyUrl,url);
                            }
                        }
                    }else{
                        content = self.LOGINED_UNJOINED_NATIVE_CONTENT;
                        sourceUrl = self.constructUrl(self.registerJoinCompanyUrl);
                    }
                }
                if(confirm(content)){
                    window.location.href = sourceUrl;
                }
            },
            error : function() {
                
            }
        });
    },
    // 应用请求服务
    transRequestService : function(uniqueCode,tagID) {
        var self = this;
        self.setting.url = "";
        var h5Map = self.html5MapArray[uniqueCode];
        if(null != h5Map){
            self.findMenuInfoByMenuIDAndCode(tagID,uniqueCode);
        }
        // 调用应用
        if(uniqueCode === "sm.menu.mobile.phone") {
            var a = $("<a href='"+'tel:' + self.setting.url+"' target='_blank'>Apple</a>").get(0);  
            var e = document.createEvent('MouseEvents');  
            e.initEvent('click', true, true);  
            a.dispatchEvent(e); 
            //window.location.href = 'tel:' + self.setting.url;
        } else if(uniqueCode === "sm.menu.link"
            || uniqueCode === "mobileportal"){
            window.location.href = self.setting.url;
        } else {
            self.getThirdPartyInfo(h5Map,self.setting.url);
        }
    },

    findMenuInfoByMenuIDAndCode : function (menuID,uniqueCode){
        var self = this;
        var companyID = this.setting.currentCompanyID;
        var data = {
            companyID : companyID,
            menuID : menuID,
            uniqueCode : uniqueCode
        }
        $.ajax({
                url : _ctxPath + '/mobilemainpageforthirdparty/findMenuContentByMenuID.json',
            data : data,
            type : 'POST',
            dataType : 'JSON',
            async : false,
            success : function (result){
                var menu = result.menuMap;
                var url = menu.url;
                self.setting.url = url;
            }
        })
    },
    checkConfirmStatus : function(isLogined,personCompanyStatus,param){
        var self = this;
        var content = "";
        if("true" == isLogined){
            if(0 == personCompanyStatus){
                if(param){
                    content = self.LOGINED_JOINED_NATIVE_CONTENT;
                }else{
                    callback && callback.call(self,param);
                }
            }else{
                // 直接加入社区
                var sourceUrl = self.constructUrl(joinCompanyUrl);
                window.location.href = sourceUrl;
            }
        }else{
            // 注册加入社区
            var sourceUrl = self.constructUrl(registerJoinCompanyUrl);
            window.location.href = sourceUrl;
        }
    }
});